from aiogram import Bot, Dispatcher

TOKEN = '6414838652:AAH2Xcf8lRrFVa7MrDTNUozp9PeE31DMC2Y'
bot = Bot(token=TOKEN)
dp = Dispatcher(bot)
